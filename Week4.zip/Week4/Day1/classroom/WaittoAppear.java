package week4Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaittoAppear {

	public static void main(String[] args)
	{
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.leafground.com/pages/appear.html");
		driver.manage().window().maximize();
		WebDriverWait wait=new WebDriverWait(driver,30);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//b[text()='Voila! I'm here Guys']")));
		driver.findElementByXPath("//b[text()='Voila! I'm here Guys']").click();
	}

}
