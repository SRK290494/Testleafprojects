package week4Day1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Snapdeal {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.snapdeal.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		WebElement Mens = driver.findElementByPartialLinkText("Men");
		Actions builder=new Actions(driver);
		builder.moveToElement(Mens).perform();
		driver.findElementByLinkText("Shirts").click();
		Thread.sleep(2000);
		WebElement Mensshirts = driver.findElementByXPath("//img[@title='Hangup Cotton Blend Multi Prints Shirt']");
		builder.moveToElement(Mensshirts).perform();
		driver.findElementByXPath("//div[contains(text(),'Quick View')]").click();
		driver.close();
		
	}

}
