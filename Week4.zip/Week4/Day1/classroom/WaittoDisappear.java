package week4Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaittoDisappear {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.leafground.com/pages/disapper.html");
		driver.manage().window().maximize();
		WebDriverWait wait=new WebDriverWait(driver,30);	
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//b[text()='I'm going to disappear. Keep looking at me!!']")));
		String text=driver.findElementByXPath("//b[text()='I'm going to disappear. Keep looking at me!!").getText();
		System.out.println(text);
		
	}

}
