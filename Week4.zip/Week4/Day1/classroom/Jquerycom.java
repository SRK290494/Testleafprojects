package week4Day1;

import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Jquerycom {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://jqueryui.com/sortable/");
		driver.manage().window().maximize();
		driver.switchTo().frame(0);
		Thread.sleep(2000);
		WebElement item1 = driver.findElementByXPath("//li[text()='Item 1']");
		WebElement item4 = driver.findElementByXPath("//li[text()='Item 4']");
		Point location=item4.getLocation();
		int xloc=location.getX();
		int yloc=location.getY();
		Actions builder=new Actions(driver);
		//builder.dragAndDrop(item1, item4).perform();
		//builder.click(item1).clickAndHold().keyDown(Keys.SHIFT).moveToElement(item4).release().perform();
		builder.dragAndDropBy(item1, xloc, yloc).perform();

	}

}
