package week4Day1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Assignment2_Myntra {

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.myntra.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		WebElement women=driver.findElementByXPath("//a[text()='Women']");
		Actions builder=new Actions(driver);
		builder.moveToElement(women).perform();
		Thread.sleep(2000);
		driver.findElementByXPath("//a[text()='Jackets & Coats']").click();
		Thread.sleep(2000);
		String items=driver.findElementByClassName("title-count").getText();
		System.out.println(items);
		items=items.replaceAll("[^0-9.]", ""); 
		int itemscount=Integer.parseInt(items);
		System.out.println("Total item count:"+itemscount);
		String jacket=driver.findElementByXPath("(//span[@class='categories-num'])[1]").getText();
		String coat=driver.findElementByXPath("(//span[@class='categories-num'])[2]").getText();
		jacket=jacket.replaceAll("[^0-9.]", "");
		coat=coat.replaceAll("[^0-9.]", "");
		System.out.println(jacket);
		System.out.println(coat);
		int jacketcount=Integer.parseInt(jacket);
		int coatcount=Integer.parseInt(coat);
		int catagoriessum=jacketcount+coatcount;
		System.out.println(catagoriessum);
		if (itemscount==catagoriessum) 
		{
			System.out.println("Itemcount and catagoriescount matches");
		}
		else
		{
			System.out.println("Itemcount and catagoriescount not matches");
		}
		driver.findElementByXPath("(//div[@class='common-checkboxIndicator'])[3]").click();
		driver.findElementByXPath("//div[@class='brand-more']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//input[@class='FilterDirectory-searchInput']").sendKeys("MANGO");
		Thread.sleep(2000);
		driver.findElementByXPath("//label[@class=' common-customCheckbox']//div[1]").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class='FilterDirectory-titleBar']//span[1]").click();
		WebElement sort=driver.findElementByXPath("//div[@class='sort-sortBy']");
		builder.moveToElement(sort).perform();
		Thread.sleep(2000);
		driver.findElementByXPath("//label[text()='Better Discount']").click();
		Thread.sleep(2000);
		String price=driver.findElementByXPath("//span[text()='5193']").getText();
		price=price.replaceAll("[^0-9.]", ""); 
		int Pricecount=Integer.parseInt(price);
		System.out.println("First display item price:"+Pricecount);
		WebElement firstitem=driver.findElementByXPath("//img[@title='MANGO Black Solid Overcoat']");
		builder.moveToElement(firstitem).perform();
		Thread.sleep(2000);
		driver.findElementByXPath("(//span[@class='product-actionsButton product-wishlist '])[1]").click();
		driver.close();
	}

}
