package week4Day1;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Assignment1_UIPATH {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://acme-test.uipath.com/account/login");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElementById("email").sendKeys("kumar.testleaf@gmail.com",Keys.TAB);
		driver.findElementById("password").sendKeys("leaf@12");
		driver.findElementById("buttonLogin").click();
		Thread.sleep(2000);
		Actions builder=new Actions(driver);
		WebElement vendor=driver.findElementByXPath("(//button[@class='btn btn-default btn-lg'])[4]");
		//WebElement vendor=driver.findElementByXPath("(//button[text()=' Vendors']");
		builder.moveToElement(vendor).perform();
		driver.findElementByXPath("//a[text()='Search for Vendor']").click();
		driver.findElementById("vendorName").sendKeys("Blue Lagoon");
		driver.findElementByXPath("//button[@id='buttonSearch']").click();
		List<WebElement> rows=driver.findElementsByXPath("//table[@class='table']//tr");
		System.out.println(rows.size());
		for (int i = 0; i < rows.size(); i++)
		{
			if (driver.findElementByXPath("//td[1]").getText().equalsIgnoreCase("Blue Lagoon"))
			{
				String countryname1=driver.findElementByXPath("//td[5]").getText();
				System.out.println("Country Name:"+countryname1);
				break;
			}
		}
		
	}

}
