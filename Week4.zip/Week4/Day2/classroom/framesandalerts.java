import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class framesandalerts {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		WebElement frame=driver.findElementById("iframeResult");
		driver.switchTo().frame(frame);
		driver.findElementByXPath("//button[text()='Try it']").click();
		Alert alert=driver.switchTo().alert();
		alert.sendKeys("Siva");
		//Thread.sleep(2000);
		alert.accept();
		Thread.sleep(3000);
		//driver.switchTo().frame(frame);
		String name = driver.findElementByXPath("//p[contains(text(),'Siva')]").getText();
		//String name = driver.findElementById("demo").getText();
		System.out.println(name);
		if (name.contains("Siva")) 
		{
		System.out.println("Name is exist in the text");
		}
		else
			System.out.println("Name not exist");
		}
		
	}

