import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class IRCTC {

	public static void main(String[] args) throws InterruptedException, IOException
	{
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.irctc.co.in/nget/train-search");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		//Thread.sleep(4000);
		driver.findElementByXPath("//button[text()='Ok']").click();
		driver.findElementByXPath("//a[text()=' FLIGHTS ']").click();
		Thread.sleep(2000);
		Set<String> firstandsecondwindow=driver.getWindowHandles();
		List<String> listhandles=new ArrayList<String>(firstandsecondwindow);
		String secondwindow=listhandles.get(1);
		driver.switchTo().window(listhandles.get(1));
		//Alert alert=driver.switchTo().alert();
		WebElement checkbox=driver.findElementById("agree");
		Actions action=new Actions(driver);
		action.moveToElement(checkbox).click().perform();
		driver.findElementByXPath("//button[text()='Continue ']").click();
		
		//Take Screenshot
		File source=driver.getScreenshotAs(OutputType.FILE);
		File target=new File("C:\\Users\\user\\Desktop\\flight.png");
		FileUtils.copyFile(source,target);
		
		//Close the first window alone
		driver.switchTo().window(listhandles.get(0));
		driver.close();
				
		
	}

}
