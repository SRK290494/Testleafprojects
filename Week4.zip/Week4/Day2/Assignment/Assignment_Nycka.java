import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Assignment_Nycka {

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.nykaa.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		//Mouse over on Brand and popular
		WebElement brand=driver.findElementByXPath("//a[text()='brands']");
		WebElement Popular=driver.findElementByXPath("//a[text()='Popular']");
		Actions action=new Actions(driver);
		action.moveToElement(brand).perform();;
		action.moveToElement(Popular).perform();
		
		//click lorial paris
		driver.findElementByXPath("//a[@href='/brands/loreal-paris/c/595?eq=desktop']").click();
		
		//Moving to new window and close old window
		Set<String> firstandsecondwindow=driver.getWindowHandles();
		List<String> listhandles=new ArrayList<String>(firstandsecondwindow);
		String secondwindow=listhandles.get(1);
		driver.switchTo().window(listhandles.get(1));
		String windowtitle=driver.getTitle();
		System.out.println(windowtitle);
		driver.switchTo().window(listhandles.get(0));
		driver.close();
		driver.switchTo().window(listhandles.get(1));
		
		//Click on sortby and customertoprated
		driver.findElementByXPath("//div[@class='sort-btn clearfix']").click();
		driver.findElementByXPath("(//div[@class='control__indicator radio'])[4]").click();
		Thread.sleep(2000);
		//click on catagories and shampoo
		driver.findElementByXPath("//div[@class='filter-sidebar__filter-wrap']").click();
		driver.findElementByXPath("(//div[@class='control__indicator'])[31]").click();
		
		//click on first item
		driver.findElementByXPath("(//img[@class='listing-img'])[1]").click();
		
		// Moving to new window 
		Set<String> Window1=driver.getWindowHandles();
		List<String> listhandles1=new ArrayList<String>(Window1);
		driver.switchTo().window(listhandles1.get(1));
		driver.findElementByXPath("//button[@class='combo-add-to-btn prdt-des-btn js--toggle-sbag nk-btn nk-btn-rnd atc-simple m-content__product-list__cart-btn  ']").click();
		
		//shoppingbag and click procceed
		driver.findElementByXPath("//div[@class='AddBagIcon']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//button[@class='btn full fill no-radius proceed ']").click();
		
		//Get the error message and close the browser
		String Erromessage=driver.findElementByXPath("//div[@class='popup-error']").getText();
		System.out.println(Erromessage);
		driver.quit();;
		
		
		
	}

}
